#!/bin/bash
# Kerekes Handshake: High-Integrity JSON Seal & Deploy (macOS Optimized)
# v1.8 - Integrated Header Validation & Public Key Handshake Verification

FINGERPRINT="D39E 4ACE A4FE 3E6B 547F 58C4 6174 3446 DFA7 D48F"
CORE_FILES=("index.html" "resume.html" "3-bullet.html" "vault-resume.html" "validator.html")
PUB_KEYS=("verify/pubkey.txt" "verify/pubkey.txt.asc")

echo "Step 0: Validating HTML Header Identity Anchors..."
for page in "${CORE_FILES[@]}"; do
    if [ -f "$page" ]; then
        if ! grep -q "$FINGERPRINT" "$page"; then
            echo "❌ ERROR: PGP Fingerprint missing from <meta> in $page."
            echo "Please ensure <meta name=\"pgp-fingerprint\" content=\"$FINGERPRINT\"> is in the <head>."
            exit 1
        fi
        echo "✅ Verified: $page contains valid Identity Anchor."
    fi
done

echo "Step 0.5: Verifying Public Key Availability..."
for key in "${PUB_KEYS[@]}"; do
    if [ ! -s "$key" ]; then
        echo "❌ ERROR: Public key file $key is missing or empty."
        echo "Ensure you have exported and signed your key to this location."
        exit 1
    fi
    echo "✅ Verified: $key is present and populated."
done

echo "Step 1: Synchronizing AI Text Sidecars..."
# Creates .txt files for any PDF if they are missing or outdated.
for f in evidence/*.pdf archive/*.pdf; do
    if [ -f "$f" ]; then
        if [ ! -f "${f%.pdf}.txt" ] || [ "$f" -nt "${f%.pdf}.txt" ]; then
            pdftotext "$f" "${f%.pdf}.txt"
            echo "Updated: ${f%.pdf}.txt"
        fi
    fi
done

echo "Step 2: Generating Refined JSON Manifest..."
# Create the root JSON object
echo "{" > site_manifest.json
echo "  \"steward\": \"Jeffrey Kerekes — $FINGERPRINT\"," >> site_manifest.json
echo "  \"timestamp\": \"$(date -u +"%Y-%m-%dT%H:%M:%SZ")\"," >> site_manifest.json
echo "  \"files\": [" >> site_manifest.json

# Loop through all files to generate SHA-256 fingerprints.
find . -type f \
    -not -path '*/.*' \
    -not -name 'site_manifest.*' \
    -not -name 'wrangler.toml' \
    -not -path './evidence/index.html' \
    -not -path './archive/index.html' \
    | while read -r file; do
    clean_path=${file#./}
    # macOS native shasum
    hash=$(shasum -a 256 "$file" | awk '{print $1}')
    echo "    {\"path\": \"$clean_path\", \"sha256\": \"$hash\"}," >> site_manifest.json
done

# macOS Sed Fix: Remove the trailing comma from the final array item
sed -i "" '$ s/,$//' site_manifest.json
echo "  ]" >> site_manifest.json
echo "}" >> site_manifest.json

echo "Step 3: PGP Sealing the JSON Manifest..."
# We use --clearsign so the JSON remains human/AI readable inside the signature block.
if gpg --yes --clearsign site_manifest.json; then
    echo "✅ PGP Seal Applied Successfully."
else
    echo "❌ ERROR: PGP Signing Failed. Check your gpg-agent or passphrase."
    exit 1
fi

echo "Step 4: Atomic Cloudflare Deployment via Wrangler..."
# Ensure you are logged into wrangler before running this.
wrangler pages deploy .

echo "---"
echo "HANDSHAKE COMPLETE: Site is live and verified."