# Grok QuickStart – Machine Instructions (v1.6) — UPDATED

**Purpose:** Upload this file + all supporting documents to Grok so it builds a complete Kerekes Handshake v1.6 vault **and** guides the user step-by-step through the remaining setup.

**Files to upload to Grok (in this exact order):**
1. KEREKES_HANDSHAKE_DEBUG.md
2. 2-GROK_QUICKSTART_Machine.md (this file)
3. _worker.js (use exactly as-is — do not regenerate)
4. SPEC.md
5. User’s resume (PDF or text)
6. ALL evidence PDFs + matching .txt sidecars

**CRITICAL OUTPUT REQUIREMENTS — Grok MUST follow these exactly:**

1. Generate **two separate files**:
   - `claims.json` (full v1.6 structure with every claim from the resume)
   - `resume.html` (with full KCM markup, flow-summary section, prominent audit button, and visible KCM-CLAIMS fallback line)

2. After delivering the two files, switch to **interactive step-by-step mode**:
   - Tell the user: “I have generated claims.json and resume.html. Reply with ‘next step’ and I will guide you one command at a time through PGP key setup and Wrangler/Cloudflare deployment.”
   - Do not dump all commands at once. Wait for the user to reply “next step” before giving the next instruction.

**Exact Prompt to paste to Grok:**

"I am uploading the full Kerekes Handshake QuickStart package plus my resume and ALL evidence files.  
Build a complete v1.6 (or newer) verifiable vault.

OUTPUT EXACTLY THESE TWO FILES FIRST:
1. claims.json (full v1.6 structure with every claim from my resume)
2. resume.html (with full KCM markup, flow-summary, audit button, and visible KCM-CLAIMS line)

Then switch to interactive mode: After giving me the files, tell me to reply with ‘next step’ and guide me one command at a time through PGP key setup and Wrangler/Cloudflare deployment.

Follow all rules in KEREKES_HANDSHAKE_DEBUG.md and use _worker.js exactly as provided.

Audience: [your audience, e.g. HR recruiters or non-technical buyers]"